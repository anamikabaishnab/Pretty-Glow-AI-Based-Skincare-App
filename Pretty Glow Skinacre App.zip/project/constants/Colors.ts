const tintColorLight = '#FF89A9';
const tintColorDark = '#FF89A9';

export default {
  light: {
    text: '#333333',
    background: '#F8F7FA',
    tint: tintColorLight,
    tabIconDefault: '#CCCCCC',
    tabIconSelected: tintColorLight,
    card: '#FFFFFF',
    border: '#EEEEEE',
    notification: '#FF3B30',
    primary: '#FF89A9',
    secondary: '#B39DDB',
    accent: '#FFC0CB',
    success: '#4CD964',
    warning: '#FF9500',
    error: '#FF3B30',
    muted: '#8E8E93',
  },
  dark: {
    text: '#F5F5F7',
    background: '#1A1A1A',
    tint: tintColorDark,
    tabIconDefault: '#8E8E93',
    tabIconSelected: tintColorDark,
    card: '#2C2C2E',
    border: '#38383A',
    notification: '#FF453A',
    primary: '#FF89A9',
    secondary: '#B39DDB',
    accent: '#FFC0CB',
    success: '#30D158',
    warning: '#FF9F0A',
    error: '#FF453A',
    muted: '#8E8E93',
  },
};