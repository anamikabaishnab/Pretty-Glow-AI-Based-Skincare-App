export const FontSizes = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 20,
  xl: 24,
  '2xl': 30,
  '3xl': 36,
};

export const FontWeights = {
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
};

export const LineHeights = {
  body: 1.5,   // 150% for body text
  heading: 1.2, // 120% for headings
  tight: 1.1,  // For tight text like buttons
  loose: 1.8,  // For more spacious text
};

export const FontFamilies = {
  regular: 'Inter-Regular',
  medium: 'Inter-Medium',
  semibold: 'Inter-SemiBold',
  bold: 'Inter-Bold',
  heading: 'PlayfairDisplay-Regular',
  headingBold: 'PlayfairDisplay-Bold',
};