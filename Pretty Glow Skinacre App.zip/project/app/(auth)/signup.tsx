import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { ArrowLeft, UserPlus } from 'lucide-react-native';

export default function SignUp() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSignUp = () => {
    // Basic validation
    if (!name || !email || !password) {
      setError('Please fill in all fields');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    // Clear previous errors
    setError('');
    setIsLoading(true);

    // Simulate sign up (replace with actual authentication)
    setTimeout(() => {
      setIsLoading(false);
      // After sign up, navigate to the quiz
      router.push('/(quiz)');
    }, 1500);
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <StatusBar style="dark" />
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={() => router.back()}
            style={styles.backButton}
          >
            <ArrowLeft size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Create Account</Text>
        </View>

        <View style={styles.formContainer}>
          <Text style={styles.subtitle}>Start your skincare journey</Text>

          {error ? (
            <View style={styles.errorContainer}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Full Name</Text>
            <TextInput
              style={styles.input}
              placeholder="Your name"
              value={name}
              onChangeText={setName}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              placeholder="Your email"
              keyboardType="email-address"
              autoCapitalize="none"
              value={email}
              onChangeText={setEmail}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Password</Text>
            <TextInput
              style={styles.input}
              placeholder="Create a password"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
            />
            <Text style={styles.helperText}>
              Must be at least 6 characters
            </Text>
          </View>

          <TouchableOpacity
            style={[styles.button, isLoading && styles.buttonDisabled]}
            onPress={handleSignUp}
            disabled={isLoading}
          >
            <Text style={styles.buttonText}>
              {isLoading ? 'Creating account...' : 'Create Account'}
            </Text>
            {!isLoading && <UserPlus size={20} color="white" style={{ marginLeft: 8 }} />}
          </TouchableOpacity>

          <View style={styles.footerContainer}>
            <Text style={styles.footerText}>Already have an account? </Text>
            <TouchableOpacity onPress={() => router.push('/(auth)/login')}>
              <Text style={styles.footerLink}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#F8F7FA',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 40,
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes['2xl'],
    color: '#333',
    marginLeft: 12,
  },
  formContainer: {
    flex: 1,
    width: '100%',
  },
  subtitle: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.lg,
    color: '#666',
    marginBottom: 30,
  },
  errorContainer: {
    backgroundColor: '#FFEBEE',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  errorText: {
    fontFamily: FontFamilies.medium,
    color: '#D32F2F',
    fontSize: FontSizes.sm,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#555',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'white',
    height: 56,
    borderRadius: 12,
    paddingHorizontal: 16,
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    borderWidth: 1,
    borderColor: '#EEEEEE',
  },
  helperText: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#888',
    marginTop: 6,
    marginLeft: 4,
  },
  button: {
    backgroundColor: '#FF89A9',
    height: 56,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#FFBFCD',
    shadowOpacity: 0.1,
  },
  buttonText: {
    color: 'white',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
  },
  footerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 30,
  },
  footerText: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
  },
  footerLink: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#FF89A9',
  },
});