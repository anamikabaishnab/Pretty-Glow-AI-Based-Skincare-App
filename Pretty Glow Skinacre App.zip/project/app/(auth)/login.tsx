import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { ArrowLeft, LogIn } from 'lucide-react-native';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = () => {
    // Basic validation
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    // Clear previous errors
    setError('');
    setIsLoading(true);

    // Simulate login (replace with actual authentication)
    setTimeout(() => {
      setIsLoading(false);
      // For now, just navigate to the main app
      router.push('/(tabs)');
    }, 1500);
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <StatusBar style="dark" />
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={() => router.back()}
            style={styles.backButton}
          >
            <ArrowLeft size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Welcome Back</Text>
        </View>

        <View style={styles.formContainer}>
          <Text style={styles.subtitle}>Sign in to your account</Text>

          {error ? (
            <View style={styles.errorContainer}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              placeholder="Your email"
              keyboardType="email-address"
              autoCapitalize="none"
              value={email}
              onChangeText={setEmail}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Password</Text>
            <TextInput
              style={styles.input}
              placeholder="Your password"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
            />
          </View>

          <TouchableOpacity style={styles.forgotPassword}>
            <Text style={styles.forgotPasswordText}>Forgot password?</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, isLoading && styles.buttonDisabled]}
            onPress={handleLogin}
            disabled={isLoading}
          >
            <Text style={styles.buttonText}>
              {isLoading ? 'Signing in...' : 'Sign In'}
            </Text>
            {!isLoading && <LogIn size={20} color="white" style={{ marginLeft: 8 }} />}
          </TouchableOpacity>

          <View style={styles.footerContainer}>
            <Text style={styles.footerText}>Don't have an account? </Text>
            <TouchableOpacity onPress={() => router.push('/(auth)/signup')}>
              <Text style={styles.footerLink}>Sign Up</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#F8F7FA',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 40,
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes['2xl'],
    color: '#333',
    marginLeft: 12,
  },
  formContainer: {
    flex: 1,
    width: '100%',
  },
  subtitle: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.lg,
    color: '#666',
    marginBottom: 30,
  },
  errorContainer: {
    backgroundColor: '#FFEBEE',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  errorText: {
    fontFamily: FontFamilies.medium,
    color: '#D32F2F',
    fontSize: FontSizes.sm,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#555',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'white',
    height: 56,
    borderRadius: 12,
    paddingHorizontal: 16,
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    borderWidth: 1,
    borderColor: '#EEEEEE',
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginBottom: 30,
  },
  forgotPasswordText: {
    color: '#FF89A9',
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
  },
  button: {
    backgroundColor: '#FF89A9',
    height: 56,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#FFBFCD',
    shadowOpacity: 0.1,
  },
  buttonText: {
    color: 'white',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
  },
  footerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 30,
  },
  footerText: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
  },
  footerLink: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#FF89A9',
  },
});