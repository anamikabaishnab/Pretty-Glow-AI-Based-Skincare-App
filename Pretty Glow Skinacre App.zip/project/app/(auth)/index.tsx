import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { Link } from 'expo-router';

export default function Welcome() {
  return (
    <LinearGradient
      colors={['#FFF4F8', '#F8F7FA']}
      style={styles.container}
    >
      <StatusBar style="dark" />
      <View style={styles.logoContainer}>
        <Text style={styles.logoText}>Pretty Glow</Text>
        <Text style={styles.tagline}>Your personalized skincare journey</Text>
      </View>

      <Image
        source={{ uri: 'https://images.pexels.com/photos/3762453/pexels-photo-3762453.jpeg' }}
        style={styles.heroImage}
      />

      <View style={styles.content}>
        <Text style={styles.title}>Discover Your Perfect Skincare Routine</Text>
        <Text style={styles.description}>
          Personalized recommendations based on your skin type, concerns, and budget
        </Text>

        <View style={styles.buttonContainer}>
          <Link href="/(auth)/signup" asChild>
            <TouchableOpacity style={styles.button}>
              <Text style={styles.buttonText}>Get Started</Text>
            </TouchableOpacity>
          </Link>
          <Link href="/(auth)/login" asChild>
            <TouchableOpacity style={styles.secondaryButton}>
              <Text style={styles.secondaryButtonText}>Sign In</Text>
            </TouchableOpacity>
          </Link>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 60,
    paddingHorizontal: 24,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  logoText: {
    fontFamily: FontFamilies.headingBold,
    fontSize: 30,
    color: '#FF89A9',
    letterSpacing: 1,
  },
  tagline: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.sm,
    color: '#666',
    marginTop: 4,
  },
  heroImage: {
    width: '90%',
    height: 300,
    borderRadius: 24,
    marginVertical: 30,
  },
  content: {
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes['2xl'],
    textAlign: 'center',
    color: '#333',
    marginBottom: 16,
  },
  description: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    textAlign: 'center',
    color: '#666',
    marginBottom: 32,
    lineHeight: 24,
  },
  buttonContainer: {
    width: '100%',
    gap: 16,
  },
  button: {
    backgroundColor: '#FF89A9',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonText: {
    color: 'white',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FF89A9',
  },
  secondaryButtonText: {
    color: '#FF89A9',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
  },
});