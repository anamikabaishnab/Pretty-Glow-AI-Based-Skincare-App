import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Image, FlatList } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Search, Filter, ChevronRight } from 'lucide-react-native';
import { FontFamilies, FontSizes } from '@/constants/Fonts';

// Mock data
const categories = [
  { id: '1', name: 'Cleanser', icon: '🧼' },
  { id: '2', name: 'Toner', icon: '💧' },
  { id: '3', name: 'Serum', icon: '✨' },
  { id: '4', name: 'Moisturizer', icon: '🧴' },
  { id: '5', name: 'Sunscreen', icon: '☀️' },
  { id: '6', name: 'Mask', icon: '😷' },
];

const concerns = [
  { id: '1', name: 'Acne', image: 'https://images.pexels.com/photos/7366363/pexels-photo-7366363.jpeg' },
  { id: '2', name: 'Anti-aging', image: 'https://images.pexels.com/photos/3786057/pexels-photo-3786057.jpeg' },
  { id: '3', name: 'Dryness', image: 'https://images.pexels.com/photos/4465831/pexels-photo-4465831.jpeg' },
  { id: '4', name: 'Hyperpigmentation', image: 'https://images.pexels.com/photos/5069439/pexels-photo-5069439.jpeg' },
];

const products = [
  {
    id: '1',
    name: 'Rose Petal Toner',
    brand: 'Glow Labs',
    price: 28.99,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/5069606/pexels-photo-5069606.jpeg'
  },
  {
    id: '2',
    name: 'Vitamin C Serum',
    brand: 'Dewdrops',
    price: 42.50,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/4465124/pexels-photo-4465124.jpeg'
  },
  {
    id: '3',
    name: 'Overnight Repair Cream',
    brand: 'Pure Beauty',
    price: 35.99,
    rating: 4.7,
    image: 'https://images.pexels.com/photos/6621339/pexels-photo-6621339.jpeg'
  },
  {
    id: '4',
    name: 'Gentle Face Wash',
    brand: 'Glow Labs',
    price: 22.99,
    rating: 4.6,
    image: 'https://images.pexels.com/photos/6621274/pexels-photo-6621274.jpeg'
  },
];

export default function DiscoverScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  // Simple filter logic - would be more complex in a real app
  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.brand.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderCategoryItem = ({ item }: { item: typeof categories[0] }) => (
    <TouchableOpacity style={styles.categoryItem}>
      <Text style={styles.categoryIcon}>{item.icon}</Text>
      <Text style={styles.categoryName}>{item.name}</Text>
    </TouchableOpacity>
  );

  const renderProductItem = ({ item }: { item: typeof products[0] }) => (
    <TouchableOpacity style={styles.productCard}>
      <Image source={{ uri: item.image }} style={styles.productImage} />
      <View style={styles.productInfo}>
        <Text style={styles.productBrand}>{item.brand}</Text>
        <Text style={styles.productName}>{item.name}</Text>
        <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
        <View style={styles.productRating}>
          <Text style={styles.ratingText}>{item.rating}</Text>
          <Text style={styles.ratingStars}>★★★★★</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.pageTitle}>Discover</Text>
        <Text style={styles.pageSubtitle}>Find products for your skin</Text>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Search size={20} color="#999" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search products, brands..."
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <TouchableOpacity 
          style={styles.filterButton}
          onPress={() => setShowFilters(!showFilters)}
        >
          <Filter size={20} color="#333" />
        </TouchableOpacity>
      </View>

      {showFilters && (
        <View style={styles.filtersContainer}>
          <Text style={styles.filterTitle}>Filter By:</Text>
          <View style={styles.filterOptions}>
            <TouchableOpacity style={styles.filterPill}>
              <Text style={styles.filterPillText}>Price: Low to High</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.filterPill}>
              <Text style={styles.filterPillText}>Rating: 4+ Stars</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.filterPill}>
              <Text style={styles.filterPillText}>Clean Beauty</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Categories</Text>
        </View>

        <FlatList
          data={categories}
          renderItem={renderCategoryItem}
          keyExtractor={item => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesContainer}
        />

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Shop by Concern</Text>
          <TouchableOpacity>
            <Text style={styles.sectionAction}>See All</Text>
          </TouchableOpacity>
        </View>

        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.concernsContainer}
        >
          {concerns.map((concern) => (
            <TouchableOpacity key={concern.id} style={styles.concernCard}>
              <Image source={{ uri: concern.image }} style={styles.concernImage} />
              <View style={styles.concernOverlay}>
                <Text style={styles.concernName}>{concern.name}</Text>
                <ChevronRight size={16} color="white" />
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Popular Products</Text>
          <TouchableOpacity>
            <Text style={styles.sectionAction}>See All</Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={filteredProducts}
          renderItem={renderProductItem}
          keyExtractor={item => item.id}
          numColumns={2}
          contentContainerStyle={styles.productsGrid}
          columnWrapperStyle={styles.productRow}
          scrollEnabled={false}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F7FA',
    paddingTop: 60,
    paddingBottom: 80, // For tab bar
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  pageTitle: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes['2xl'],
    color: '#333',
    marginBottom: 4,
  },
  pageSubtitle: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  searchBar: {
    flex: 1,
    height: 48,
    backgroundColor: 'white',
    borderRadius: 12,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#333',
  },
  filterButton: {
    width: 48,
    height: 48,
    backgroundColor: 'white',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  filtersContainer: {
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingVertical: 16,
    marginHorizontal: 20,
    borderRadius: 12,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  filterTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 12,
  },
  filterOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  filterPill: {
    backgroundColor: '#FFF4F8',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  filterPillText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#FF89A9',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  sectionTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
  },
  sectionAction: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#FF89A9',
  },
  categoriesContainer: {
    paddingHorizontal: 20,
    marginBottom: 28,
  },
  categoryItem: {
    alignItems: 'center',
    marginRight: 24,
    width: 68,
  },
  categoryIcon: {
    fontSize: 28,
    marginBottom: 8,
  },
  categoryName: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#666',
    textAlign: 'center',
  },
  concernsContainer: {
    paddingHorizontal: 20,
    marginBottom: 28,
  },
  concernCard: {
    width: 160,
    height: 100,
    marginRight: 12,
    borderRadius: 12,
    overflow: 'hidden',
  },
  concernImage: {
    width: '100%',
    height: '100%',
  },
  concernOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.4)',
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  concernName: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.sm,
    color: 'white',
  },
  productsGrid: {
    paddingHorizontal: 20,
    paddingBottom: 90,
  },
  productRow: {
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  productCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    width: '48%',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  productImage: {
    width: '100%',
    height: 160,
  },
  productInfo: {
    padding: 12,
  },
  productBrand: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#666',
    marginBottom: 4,
  },
  productName: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 6,
    height: 44, // Fixed height for 2 lines
  },
  productPrice: {
    fontFamily: FontFamilies.bold,
    fontSize: FontSizes.md,
    color: '#FF89A9',
    marginBottom: 6,
  },
  productRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.xs,
    color: '#666',
    marginRight: 4,
  },
  ratingStars: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#FFB800',
  },
});