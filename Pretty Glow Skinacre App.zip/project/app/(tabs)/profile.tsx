import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Switch } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { Settings, LogOut, Bell, Shield, HelpCircle, ChevronRight } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useState } from 'react';

export default function ProfileScreen() {
  const router = useRouter();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  
  const handleLogout = () => {
    // In a real app, implement actual logout
    router.push('/(auth)');
  };
  
  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.pageTitle}>Profile</Text>
        <TouchableOpacity style={styles.settingsButton}>
          <Settings size={24} color="#333" />
        </TouchableOpacity>
      </View>
      
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.profileSection}>
          <Image
            source={{ uri: 'https://images.pexels.com/photos/3764119/pexels-photo-3764119.jpeg' }}
            style={styles.profileImage}
          />
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>Emily Johnson</Text>
            <Text style={styles.profileEmail}>emily.johnson@example.com</Text>
            <TouchableOpacity style={styles.editButton}>
              <Text style={styles.editButtonText}>Edit Profile</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.statsCard}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>4</Text>
            <Text style={styles.statLabel}>Months on Routine</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>8</Text>
            <Text style={styles.statLabel}>Products Used</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>73%</Text>
            <Text style={styles.statLabel}>Skin Improvement</Text>
          </View>
        </View>
        
        <View style={styles.sectionTitle}>
          <Text style={styles.sectionTitleText}>Account Settings</Text>
        </View>
        
        <View style={styles.settingsCard}>
          <View style={styles.settingRow}>
            <View style={styles.settingIcon}>
              <Bell size={20} color="#FF89A9" />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>Notifications</Text>
              <Text style={styles.settingDescription}>Receive product alerts and reminders</Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: '#E5E5E5', true: '#FFBFCD' }}
              thumbColor={notificationsEnabled ? '#FF89A9' : '#FFF'}
            />
          </View>
          
          <TouchableOpacity style={styles.settingRow}>
            <View style={styles.settingIcon}>
              <Shield size={20} color="#FF89A9" />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>Privacy</Text>
              <Text style={styles.settingDescription}>Manage your data and privacy settings</Text>
            </View>
            <ChevronRight size={20} color="#999" />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingRow}>
            <View style={styles.settingIcon}>
              <HelpCircle size={20} color="#FF89A9" />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>Help & Support</Text>
              <Text style={styles.settingDescription}>Get help and contact support</Text>
            </View>
            <ChevronRight size={20} color="#999" />
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity 
          style={styles.deleteAccountButton}
          onPress={() => console.log('Delete account')}
        >
          <Text style={styles.deleteAccountText}>Delete Account</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <LogOut size={20} color="#FF89A9" />
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>
        
        <Text style={styles.versionText}>Pretty Glow v1.0.0</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F7FA',
    paddingTop: 60,
    paddingBottom: 80, // For tab bar
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  pageTitle: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes['2xl'],
    color: '#333',
  },
  settingsButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  profileSection: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 24,
    alignItems: 'center',
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.xl,
    color: '#333',
    marginBottom: 4,
  },
  profileEmail: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.sm,
    color: '#666',
    marginBottom: 12,
  },
  editButton: {
    backgroundColor: '#FFF4F8',
    paddingVertical: 6,
    paddingHorizontal: 16,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  editButtonText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#FF89A9',
  },
  statsCard: {
    backgroundColor: 'white',
    marginHorizontal: 20,
    borderRadius: 16,
    flexDirection: 'row',
    padding: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
    marginBottom: 24,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statNumber: {
    fontFamily: FontFamilies.bold,
    fontSize: FontSizes.xl,
    color: '#FF89A9',
    marginBottom: 4,
  },
  statLabel: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#666',
    textAlign: 'center',
  },
  statDivider: {
    width: 1,
    height: '80%',
    backgroundColor: '#F0F0F0',
  },
  sectionTitle: {
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  sectionTitleText: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
  },
  settingsCard: {
    backgroundColor: 'white',
    marginHorizontal: 20,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
    marginBottom: 24,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFF4F8',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  settingContent: {
    flex: 1,
  },
  settingLabel: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 4,
  },
  settingDescription: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.sm,
    color: '#666',
  },
  deleteAccountButton: {
    marginHorizontal: 20,
    marginBottom: 12,
    paddingVertical: 12,
    alignItems: 'center',
  },
  deleteAccountText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.md,
    color: '#FF3B30',
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFF4F8',
    borderRadius: 12,
    marginBottom: 20,
  },
  logoutText: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#FF89A9',
    marginLeft: 8,
  },
  versionText: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#999',
    textAlign: 'center',
    marginBottom: 40,
  },
});