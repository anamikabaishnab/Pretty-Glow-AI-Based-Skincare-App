import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, FlatList, Dimensions } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { BarChart } from 'react-native-chart-kit';
import { Plus, ChevronRight, ShoppingCart, Check, Trash2 } from 'lucide-react-native';

// Mock data
const shoppingItems = [
  {
    id: '1',
    name: 'Hydrating Toner',
    brand: 'Glow Labs',
    price: 24.99,
    image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg',
    purchased: true,
    dateAdded: '2023-05-20',
  },
  {
    id: '2',
    name: 'Vitamin C Serum',
    brand: 'Pure Beauty',
    price: 38.50,
    image: 'https://images.pexels.com/photos/5069606/pexels-photo-5069606.jpeg',
    purchased: false,
    dateAdded: '2023-05-15',
  },
  {
    id: '3',
    name: 'Night Cream',
    brand: 'Dewdrops',
    price: 29.99,
    image: 'https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg',
    purchased: false,
    dateAdded: '2023-05-10',
  },
];

const spendingData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      data: [20, 45, 28, 80, 99, 43],
    },
  ],
};

const screenWidth = Dimensions.get('window').width;

export default function ShoppingScreen() {
  const [activeTab, setActiveTab] = useState('wishlist');
  
  const renderShoppingItem = ({ item }: { item: typeof shoppingItems[0] }) => (
    <View style={styles.shoppingItem}>
      <Image source={{ uri: item.image }} style={styles.itemImage} />
      <View style={styles.itemInfo}>
        <Text style={styles.itemBrand}>{item.brand}</Text>
        <Text style={styles.itemName}>{item.name}</Text>
        <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>
      </View>
      <View style={styles.itemActions}>
        {item.purchased ? (
          <View style={styles.purchasedBadge}>
            <Check size={16} color="white" />
          </View>
        ) : (
          <TouchableOpacity style={styles.purchaseButton}>
            <ShoppingCart size={16} color="#FF89A9" />
          </TouchableOpacity>
        )}
        <TouchableOpacity style={styles.removeButton}>
          <Trash2 size={16} color="#999" />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.pageTitle}>Shopping</Text>
        <Text style={styles.pageSubtitle}>Track your skincare purchases</Text>
      </View>
      
      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'wishlist' && styles.activeTabButton]}
          onPress={() => setActiveTab('wishlist')}
        >
          <Text style={[
            styles.tabButtonText,
            activeTab === 'wishlist' && styles.activeTabButtonText
          ]}>Wishlist</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'purchased' && styles.activeTabButton]}
          onPress={() => setActiveTab('purchased')}
        >
          <Text style={[
            styles.tabButtonText,
            activeTab === 'purchased' && styles.activeTabButtonText
          ]}>Purchased</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === 'spending' && styles.activeTabButton]}
          onPress={() => setActiveTab('spending')}
        >
          <Text style={[
            styles.tabButtonText,
            activeTab === 'spending' && styles.activeTabButtonText
          ]}>Spending</Text>
        </TouchableOpacity>
      </View>
      
      {activeTab === 'wishlist' && (
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.listHeader}>
            <Text style={styles.listTitle}>Your Wishlist</Text>
            <TouchableOpacity style={styles.addButton}>
              <Plus size={20} color="white" />
            </TouchableOpacity>
          </View>
          
          <FlatList
            data={shoppingItems.filter(item => !item.purchased)}
            renderItem={renderShoppingItem}
            keyExtractor={item => item.id}
            scrollEnabled={false}
          />
          
          <TouchableOpacity style={styles.viewAllButton}>
            <Text style={styles.viewAllText}>View All Items</Text>
            <ChevronRight size={16} color="#FF89A9" />
          </TouchableOpacity>
        </ScrollView>
      )}

      {activeTab === 'purchased' && (
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.listHeader}>
            <Text style={styles.listTitle}>Purchased Items</Text>
            <TouchableOpacity style={styles.addButton}>
              <Plus size={20} color="white" />
            </TouchableOpacity>
          </View>
          
          <FlatList
            data={shoppingItems.filter(item => item.purchased)}
            renderItem={renderShoppingItem}
            keyExtractor={item => item.id}
            scrollEnabled={false}
          />
          
          <TouchableOpacity style={styles.viewAllButton}>
            <Text style={styles.viewAllText}>View Purchase History</Text>
            <ChevronRight size={16} color="#FF89A9" />
          </TouchableOpacity>
        </ScrollView>
      )}

      {activeTab === 'spending' && (
        <ScrollView showsVerticalScrollIndicator={false} style={styles.spendingContainer}>
          <View style={styles.spendingCard}>
            <Text style={styles.spendingTitle}>Monthly Spending</Text>
            <BarChart
              data={spendingData}
              width={screenWidth - 40}
              height={220}
              yAxisLabel="$"
              chartConfig={{
                backgroundColor: '#ffffff',
                backgroundGradientFrom: '#ffffff',
                backgroundGradientTo: '#ffffff',
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(255, 137, 169, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(102, 102, 102, ${opacity})`,
                style: {
                  borderRadius: 16,
                },
                barPercentage: 0.6,
              }}
              style={styles.chart}
            />
          </View>
          
          <View style={styles.summaryCard}>
            <Text style={styles.summaryTitle}>Spending Summary</Text>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Total Spent (2023)</Text>
              <Text style={styles.summaryValue}>$315.00</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Average Per Month</Text>
              <Text style={styles.summaryValue}>$52.50</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Most Expensive Item</Text>
              <Text style={styles.summaryValue}>$80.00</Text>
            </View>
          </View>
          
          <View style={styles.budgetCard}>
            <Text style={styles.budgetTitle}>Budget Settings</Text>
            <TouchableOpacity style={styles.budgetButton}>
              <Text style={styles.budgetButtonText}>Set Monthly Budget</Text>
              <ChevronRight size={16} color="#FF89A9" />
            </TouchableOpacity>
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F7FA',
    paddingTop: 60,
    paddingBottom: 80, // For tab bar
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  pageTitle: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes['2xl'],
    color: '#333',
    marginBottom: 4,
  },
  pageSubtitle: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
  },
  tabs: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  tabButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: 'transparent',
  },
  activeTabButton: {
    backgroundColor: '#FFF4F8',
  },
  tabButtonText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#999',
  },
  activeTabButtonText: {
    color: '#FF89A9',
  },
  listHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  listTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
  },
  addButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FF89A9',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  shoppingItem: {
    flexDirection: 'row',
    backgroundColor: 'white',
    marginHorizontal: 20,
    marginBottom: 12,
    padding: 12,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  itemImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
  },
  itemInfo: {
    flex: 1,
    marginLeft: 12,
    justifyContent: 'center',
  },
  itemBrand: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#666',
    marginBottom: 2,
  },
  itemName: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 4,
  },
  itemPrice: {
    fontFamily: FontFamilies.bold,
    fontSize: FontSizes.md,
    color: '#FF89A9',
  },
  itemActions: {
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingVertical: 4,
  },
  purchaseButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#FF89A9',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  purchasedBadge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#4CD964',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  removeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E5E5E5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
    marginBottom: 40,
  },
  viewAllText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.md,
    color: '#FF89A9',
    marginRight: 4,
  },
  spendingContainer: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  spendingCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  spendingTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
    marginBottom: 16,
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16,
  },
  summaryCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  summaryTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
    marginBottom: 16,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  summaryLabel: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
  },
  summaryValue: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
  },
  budgetCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 40,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  budgetTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
    marginBottom: 16,
  },
  budgetButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#F0F0F0',
    borderRadius: 8,
    paddingHorizontal: 16,
  },
  budgetButtonText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.md,
    color: '#FF89A9',
  },
});