import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useRouter } from 'expo-router';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { Bell, Heart } from 'lucide-react-native';

// Mock data
const recommendedProducts = [
  {
    id: '1',
    name: 'Radiance Cleanser',
    brand: 'Glow Labs',
    price: 24.99,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/5217889/pexels-photo-5217889.jpeg'
  },
  {
    id: '2',
    name: 'Hydrating Serum',
    brand: 'Dewdrops',
    price: 36.50,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/5765208/pexels-photo-5765208.jpeg'
  },
  {
    id: '3',
    name: 'Rejuvenating Mask',
    brand: 'Pure Beauty',
    price: 19.99,
    rating: 4.7,
    image: 'https://images.pexels.com/photos/6621462/pexels-photo-6621462.jpeg'
  }
];

const routineSteps = [
  {
    id: '1',
    time: 'Morning',
    steps: ['Cleanse', 'Tone', 'Moisturize', 'Sunscreen']
  },
  {
    id: '2',
    time: 'Evening',
    steps: ['Cleanse', 'Exfoliate', 'Serum', 'Night Cream']
  }
];

export default function HomeScreen() {
  const router = useRouter();
  const [favorites, setFavorites] = useState<string[]>([]);

  const toggleFavorite = (id: string) => {
    if (favorites.includes(id)) {
      setFavorites(favorites.filter(fav => fav !== id));
    } else {
      setFavorites([...favorites, id]);
    }
  };

  const viewProductDetails = (id: string) => {
    // In a real app, navigate to product details
    console.log(`Viewing product ${id}`);
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Good morning,</Text>
          <Text style={styles.userName}>Emily</Text>
        </View>
        <TouchableOpacity style={styles.notificationButton}>
          <Bell size={24} color="#333" />
        </TouchableOpacity>
      </View>
      
      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.heroCard}>
          <View style={styles.heroContent}>
            <Text style={styles.heroTitle}>Your Personalized Routine</Text>
            <Text style={styles.heroText}>
              Follow your tailored skincare routine for best results
            </Text>
            <TouchableOpacity style={styles.heroButton}>
              <Text style={styles.heroButtonText}>View Routine</Text>
            </TouchableOpacity>
          </View>
          <Image
            source={{ uri: 'https://images.pexels.com/photos/3785177/pexels-photo-3785177.jpeg' }}
            style={styles.heroImage}
          />
        </View>
        
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Your Daily Routine</Text>
          <TouchableOpacity>
            <Text style={styles.sectionAction}>Edit</Text>
          </TouchableOpacity>
        </View>
        
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.routineContainer}
        >
          {routineSteps.map((routine) => (
            <View key={routine.id} style={styles.routineCard}>
              <Text style={styles.routineTime}>{routine.time}</Text>
              <View style={styles.routineSteps}>
                {routine.steps.map((step, index) => (
                  <View key={index} style={styles.routineStep}>
                    <View style={styles.stepNumberContainer}>
                      <Text style={styles.stepNumber}>{index + 1}</Text>
                    </View>
                    <Text style={styles.stepName}>{step}</Text>
                  </View>
                ))}
              </View>
            </View>
          ))}
        </ScrollView>
        
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recommended For You</Text>
          <TouchableOpacity>
            <Text style={styles.sectionAction}>See All</Text>
          </TouchableOpacity>
        </View>
        
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.productsContainer}
        >
          {recommendedProducts.map((product) => (
            <TouchableOpacity 
              key={product.id} 
              style={styles.productCard}
              onPress={() => viewProductDetails(product.id)}
            >
              <Image
                source={{ uri: product.image }}
                style={styles.productImage}
              />
              <TouchableOpacity 
                style={styles.favoriteButton}
                onPress={() => toggleFavorite(product.id)}
              >
                <Heart 
                  size={20} 
                  color={favorites.includes(product.id) ? '#FF6B8B' : '#FFFFFF'} 
                  fill={favorites.includes(product.id) ? '#FF6B8B' : 'none'} 
                />
              </TouchableOpacity>
              <View style={styles.productInfo}>
                <Text style={styles.productBrand}>{product.brand}</Text>
                <Text style={styles.productName}>{product.name}</Text>
                <Text style={styles.productPrice}>${product.price.toFixed(2)}</Text>
                <View style={styles.productRating}>
                  <Text style={styles.ratingText}>{product.rating}</Text>
                  <Text style={styles.ratingStars}>★★★★★</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
        
        <View style={styles.tipCard}>
          <Text style={styles.tipTitle}>Skincare Tip</Text>
          <Text style={styles.tipText}>
            Apply your products in order from thinnest to thickest consistency for maximum absorption.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F7FA',
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  greeting: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
  },
  userName: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes.xl,
    color: '#333',
  },
  notificationButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  scrollContent: {
    paddingBottom: 100,
  },
  heroCard: {
    marginHorizontal: 20,
    marginBottom: 24,
    height: 160,
    backgroundColor: '#FFF4F8',
    borderRadius: 20,
    overflow: 'hidden',
    flexDirection: 'row',
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  heroContent: {
    flex: 1,
    padding: 20,
    justifyContent: 'space-between',
  },
  heroTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
    marginBottom: 8,
  },
  heroText: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.sm,
    color: '#666',
    marginBottom: 12,
    lineHeight: 20,
  },
  heroButton: {
    backgroundColor: '#FF89A9',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  heroButtonText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: 'white',
  },
  heroImage: {
    width: 120,
    height: '100%',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 16,
    marginTop: 8,
  },
  sectionTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
  },
  sectionAction: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#FF89A9',
  },
  routineContainer: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  routineCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginRight: 16,
    width: 180,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  routineTime: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 16,
  },
  routineSteps: {
    gap: 12,
  },
  routineStep: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepNumberContainer: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FFF4F8',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  stepNumber: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.xs,
    color: '#FF89A9',
  },
  stepName: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#666',
  },
  productsContainer: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  productCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    width: 160,
    marginRight: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  productImage: {
    width: '100%',
    height: 160,
  },
  favoriteButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  productInfo: {
    padding: 12,
  },
  productBrand: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#666',
    marginBottom: 4,
  },
  productName: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 6,
  },
  productPrice: {
    fontFamily: FontFamilies.bold,
    fontSize: FontSizes.md,
    color: '#FF89A9',
    marginBottom: 6,
  },
  productRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.xs,
    color: '#666',
    marginRight: 4,
  },
  ratingStars: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#FFB800',
  },
  tipCard: {
    marginHorizontal: 20,
    backgroundColor: '#F0F4FF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
  },
  tipTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 8,
  },
  tipText: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.sm,
    color: '#666',
    lineHeight: 22,
  },
});