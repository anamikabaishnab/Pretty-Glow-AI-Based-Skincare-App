import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react-native';

const skinTypes = [
  {
    id: 'dry',
    title: 'Dry',
    description: 'Feels tight, flaky, rough texture',
  },
  {
    id: 'oily',
    title: 'Oily',
    description: 'Shiny appearance, enlarged pores',
  },
  {
    id: 'combination',
    title: 'Combination',
    description: 'Oily T-zone, normal or dry cheeks',
  },
  {
    id: 'normal',
    title: 'Normal',
    description: 'Balanced, not too oily or too dry',
  },
  {
    id: 'sensitive',
    title: 'Sensitive',
    description: 'Easily irritated, prone to redness',
  },
];

export default function SkinTypeQuiz() {
  const router = useRouter();
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const handleNext = () => {
    if (selectedType) {
      // In a real app, you would save this information to user's profile
      router.push('/(quiz)/skin-concerns');
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <TouchableOpacity 
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <ArrowLeft size={24} color="#333" />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '20%' }]} />
          </View>
          <Text style={styles.progressText}>1/5</Text>
        </View>
      </View>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.question}>What's your skin type?</Text>
        <Text style={styles.instruction}>Select the option that best describes your skin most days</Text>
        
        <View style={styles.optionsContainer}>
          {skinTypes.map((type) => (
            <TouchableOpacity
              key={type.id}
              style={[
                styles.optionCard,
                selectedType === type.id && styles.selectedCard,
              ]}
              onPress={() => setSelectedType(type.id)}
            >
              <View style={styles.optionContent}>
                <Text style={styles.optionTitle}>{type.title}</Text>
                <Text style={styles.optionDescription}>{type.description}</Text>
              </View>
              {selectedType === type.id && (
                <View style={styles.checkCircle}>
                  <Check size={16} color="white" />
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity 
          style={[styles.nextButton, !selectedType && styles.buttonDisabled]}
          onPress={handleNext}
          disabled={!selectedType}
        >
          <Text style={styles.nextButtonText}>Next</Text>
          <ArrowRight size={20} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F7FA',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 40,
  },
  backButton: {
    padding: 8,
  },
  progressContainer: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'row',
    marginLeft: 16,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: '#E5E5E5',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#FF89A9',
    borderRadius: 3,
  },
  progressText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#666',
    marginLeft: 12,
  },
  content: {
    flex: 1,
  },
  question: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes.xl,
    color: '#333',
    marginBottom: 12,
  },
  instruction: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
    marginBottom: 30,
  },
  optionsContainer: {
    marginBottom: 40,
  },
  optionCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selectedCard: {
    borderColor: '#FF89A9',
    shadowColor: '#FF89A9',
    shadowOpacity: 0.2,
  },
  optionContent: {
    flex: 1,
  },
  optionTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 4,
  },
  optionDescription: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.sm,
    color: '#666',
  },
  checkCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FF89A9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  footer: {
    width: '100%',
    marginTop: 10,
  },
  nextButton: {
    backgroundColor: '#FF89A9',
    height: 56,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#FFBFCD',
    shadowOpacity: 0.1,
  },
  nextButtonText: {
    color: 'white',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    marginRight: 8,
  },
});