import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react-native';

const skinConcerns = [
  {
    id: 'acne',
    title: 'Acne & Breakouts',
  },
  {
    id: 'aging',
    title: 'Fine Lines & Wrinkles',
  },
  {
    id: 'hyperpigmentation',
    title: 'Dark Spots & Hyperpigmentation',
  },
  {
    id: 'dullness',
    title: 'Dullness & Uneven Texture',
  },
  {
    id: 'redness',
    title: 'Redness & Inflammation',
  },
  {
    id: 'dryness',
    title: 'Dryness & Flakiness',
  },
  {
    id: 'oiliness',
    title: 'Excess Oil & Shine',
  },
  {
    id: 'pores',
    title: 'Enlarged Pores',
  },
];

export default function SkinConcernsQuiz() {
  const router = useRouter();
  const [selectedConcerns, setSelectedConcerns] = useState<string[]>([]);

  const toggleConcern = (id: string) => {
    if (selectedConcerns.includes(id)) {
      setSelectedConcerns(selectedConcerns.filter(concern => concern !== id));
    } else {
      setSelectedConcerns([...selectedConcerns, id]);
    }
  };

  const handleNext = () => {
    if (selectedConcerns.length > 0) {
      // In a real app, you would save this information
      router.push('/(quiz)/budget');
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <TouchableOpacity 
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <ArrowLeft size={24} color="#333" />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '40%' }]} />
          </View>
          <Text style={styles.progressText}>2/5</Text>
        </View>
      </View>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.question}>What are your skin concerns?</Text>
        <Text style={styles.instruction}>Select all that apply to you</Text>
        
        <View style={styles.optionsContainer}>
          {skinConcerns.map((concern) => (
            <TouchableOpacity
              key={concern.id}
              style={[
                styles.optionCard,
                selectedConcerns.includes(concern.id) && styles.selectedCard,
              ]}
              onPress={() => toggleConcern(concern.id)}
            >
              <Text style={styles.optionTitle}>{concern.title}</Text>
              {selectedConcerns.includes(concern.id) && (
                <View style={styles.checkCircle}>
                  <Check size={16} color="white" />
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity 
          style={[styles.nextButton, selectedConcerns.length === 0 && styles.buttonDisabled]}
          onPress={handleNext}
          disabled={selectedConcerns.length === 0}
        >
          <Text style={styles.nextButtonText}>Next</Text>
          <ArrowRight size={20} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F7FA',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 40,
  },
  backButton: {
    padding: 8,
  },
  progressContainer: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'row',
    marginLeft: 16,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: '#E5E5E5',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#FF89A9',
    borderRadius: 3,
  },
  progressText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#666',
    marginLeft: 12,
  },
  content: {
    flex: 1,
  },
  question: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes.xl,
    color: '#333',
    marginBottom: 12,
  },
  instruction: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
    marginBottom: 30,
  },
  optionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 40,
  },
  optionCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    width: '48%',
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selectedCard: {
    borderColor: '#FF89A9',
    shadowColor: '#FF89A9',
    shadowOpacity: 0.2,
  },
  optionTitle: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#333',
    flex: 1,
  },
  checkCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FF89A9',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  footer: {
    width: '100%',
    marginTop: 10,
  },
  nextButton: {
    backgroundColor: '#FF89A9',
    height: 56,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#FFBFCD',
    shadowOpacity: 0.1,
  },
  nextButtonText: {
    color: 'white',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    marginRight: 8,
  },
});