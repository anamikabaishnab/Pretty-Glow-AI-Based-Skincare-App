import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { ArrowRight } from 'lucide-react-native';

export default function QuizIntro() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.content}>
        <Text style={styles.title}>Let's Personalize Your Skincare</Text>
        <Text style={styles.description}>
          Answer a few questions to help us recommend products that match your 
          skin type, concerns, and budget.
        </Text>

        <View style={styles.imageContainer}>
          <Image
            source={{ uri: 'https://images.pexels.com/photos/3373746/pexels-photo-3373746.jpeg' }}
            style={styles.image}
            resizeMode="cover"
          />
        </View>

        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>5</Text>
            <Text style={styles.statLabel}>Simple Questions</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>2</Text>
            <Text style={styles.statLabel}>Minutes to Complete</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>100%</Text>
            <Text style={styles.statLabel}>Personalized</Text>
          </View>
        </View>
      </View>

      <View style={styles.footer}>
        <TouchableOpacity 
          style={styles.startButton}
          onPress={() => router.push('/(quiz)/skin-type')}
        >
          <Text style={styles.startButtonText}>Start the Quiz</Text>
          <ArrowRight size={20} color="white" />
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.skipButton}
          onPress={() => router.push('/(tabs)')}
        >
          <Text style={styles.skipButtonText}>Skip for Now</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F7FA',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 40,
    justifyContent: 'space-between',
  },
  content: {
    alignItems: 'center',
  },
  title: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes['2xl'],
    textAlign: 'center',
    color: '#333',
    marginBottom: 16,
  },
  description: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    textAlign: 'center',
    color: '#666',
    marginBottom: 36,
    lineHeight: 24,
  },
  imageContainer: {
    width: '100%',
    height: 220,
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 40,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.1,
    shadowRadius: 16,
    elevation: 10,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  statsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 10,
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statNumber: {
    fontFamily: FontFamilies.bold,
    fontSize: FontSizes.xl,
    color: '#FF89A9',
    marginBottom: 4,
  },
  statLabel: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.xs,
    color: '#666',
    textAlign: 'center',
  },
  statDivider: {
    height: 40,
    width: 1,
    backgroundColor: '#E5E5E5',
  },
  footer: {
    width: '100%',
  },
  startButton: {
    backgroundColor: '#FF89A9',
    height: 56,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  startButtonText: {
    color: 'white',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    marginRight: 8,
  },
  skipButton: {
    backgroundColor: 'transparent',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  skipButtonText: {
    color: '#999',
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.md,
  },
});