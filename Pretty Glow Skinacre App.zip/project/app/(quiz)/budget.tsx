import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { ArrowLeft, ArrowRight, DollarSign } from 'lucide-react-native';

const budgetOptions = [
  {
    id: 'budget',
    title: 'Budget-Friendly',
    description: 'Affordable, effective basics',
    icon: (color: string) => <DollarSign size={20} color={color} />
  },
  {
    id: 'midrange',
    title: 'Mid-Range',
    description: 'Balance of quality and value',
    icon: (color: string) => (
      <View style={{ flexDirection: 'row' }}>
        <DollarSign size={20} color={color} />
        <DollarSign size={20} color={color} />
      </View>
    )
  },
  {
    id: 'premium',
    title: 'Premium',
    description: 'Luxury products, premium ingredients',
    icon: (color: string) => (
      <View style={{ flexDirection: 'row' }}>
        <DollarSign size={20} color={color} />
        <DollarSign size={20} color={color} />
        <DollarSign size={20} color={color} />
      </View>
    )
  },
  {
    id: 'all',
    title: 'Show All Price Ranges',
    description: 'I want to see everything',
    icon: (color: string) => (
      <View style={{ flexDirection: 'row' }}>
        <DollarSign size={20} color={color} opacity={0.5} />
        <DollarSign size={20} color={color} />
        <DollarSign size={20} color={color} />
      </View>
    )
  },
];

export default function BudgetQuiz() {
  const router = useRouter();
  const [selectedBudget, setSelectedBudget] = useState<string | null>(null);

  const handleNext = () => {
    if (selectedBudget) {
      // In a real app, you would save this information
      router.push('/(quiz)/completed');
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <TouchableOpacity 
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <ArrowLeft size={24} color="#333" />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '60%' }]} />
          </View>
          <Text style={styles.progressText}>3/5</Text>
        </View>
      </View>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.question}>What's your budget preference?</Text>
        <Text style={styles.instruction}>Select what fits your budget best</Text>
        
        <View style={styles.optionsContainer}>
          {budgetOptions.map((option) => (
            <TouchableOpacity
              key={option.id}
              style={[
                styles.optionCard,
                selectedBudget === option.id && styles.selectedCard,
              ]}
              onPress={() => setSelectedBudget(option.id)}
            >
              <View style={styles.optionIcon}>
                {option.icon(selectedBudget === option.id ? '#FF89A9' : '#999')}
              </View>
              <View style={styles.optionContent}>
                <Text style={[
                  styles.optionTitle,
                  selectedBudget === option.id && styles.selectedTitle,
                ]}>
                  {option.title}
                </Text>
                <Text style={styles.optionDescription}>{option.description}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity 
          style={[styles.nextButton, !selectedBudget && styles.buttonDisabled]}
          onPress={handleNext}
          disabled={!selectedBudget}
        >
          <Text style={styles.nextButtonText}>Next</Text>
          <ArrowRight size={20} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F7FA',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 40,
  },
  backButton: {
    padding: 8,
  },
  progressContainer: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'row',
    marginLeft: 16,
  },
  progressBar: {
    flex: 1,
    height: 6,
    backgroundColor: '#E5E5E5',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#FF89A9',
    borderRadius: 3,
  },
  progressText: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.sm,
    color: '#666',
    marginLeft: 12,
  },
  content: {
    flex: 1,
  },
  question: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes.xl,
    color: '#333',
    marginBottom: 12,
  },
  instruction: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
    marginBottom: 30,
  },
  optionsContainer: {
    marginBottom: 40,
  },
  optionCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selectedCard: {
    borderColor: '#FF89A9',
    shadowColor: '#FF89A9',
    shadowOpacity: 0.2,
  },
  optionIcon: {
    width: 60,
    alignItems: 'center',
  },
  optionContent: {
    flex: 1,
  },
  optionTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#333',
    marginBottom: 4,
  },
  selectedTitle: {
    color: '#FF89A9',
  },
  optionDescription: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.sm,
    color: '#666',
  },
  footer: {
    width: '100%',
    marginTop: 10,
  },
  nextButton: {
    backgroundColor: '#FF89A9',
    height: 56,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonDisabled: {
    backgroundColor: '#FFBFCD',
    shadowOpacity: 0.1,
  },
  nextButtonText: {
    color: 'white',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    marginRight: 8,
  },
});