import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { FontFamilies, FontSizes } from '@/constants/Fonts';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowRight, Check } from 'lucide-react-native';

export default function QuizCompleted() {
  const router = useRouter();

  return (
    <LinearGradient
      colors={['#FFF4F8', '#F8F7FA']}
      style={styles.container}
    >
      <StatusBar style="dark" />
      
      <View style={styles.content}>
        <View style={styles.checkCircle}>
          <Check size={60} color="white" />
        </View>
        
        <Text style={styles.title}>Your Profile is Complete!</Text>
        <Text style={styles.description}>
          We've created your personalized skincare routine
          based on your unique profile
        </Text>

        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>Your Skin Profile</Text>
          <View style={styles.resultItem}>
            <Text style={styles.resultLabel}>Skin Type:</Text>
            <Text style={styles.resultValue}>Combination</Text>
          </View>
          <View style={styles.resultItem}>
            <Text style={styles.resultLabel}>Top Concerns:</Text>
            <Text style={styles.resultValue}>Acne, Dullness</Text>
          </View>
          <View style={styles.resultItem}>
            <Text style={styles.resultLabel}>Budget:</Text>
            <Text style={styles.resultValue}>Mid-Range</Text>
          </View>
        </View>

        <View style={styles.imageContainer}>
          <Image
            source={{ uri: 'https://images.pexels.com/photos/3321586/pexels-photo-3321586.jpeg' }}
            style={styles.image}
            resizeMode="cover"
          />
        </View>
      </View>

      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => router.push('/(tabs)')}
        >
          <Text style={styles.buttonText}>View My Routine</Text>
          <ArrowRight size={20} color="white" />
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 80,
    paddingBottom: 40,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    width: '100%',
  },
  checkCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#FF89A9',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 10,
  },
  title: {
    fontFamily: FontFamilies.heading,
    fontSize: FontSizes['2xl'],
    color: '#333',
    textAlign: 'center',
    marginBottom: 16,
  },
  description: {
    fontFamily: FontFamilies.regular,
    fontSize: FontSizes.md,
    color: '#666',
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
  },
  resultCard: {
    backgroundColor: 'white',
    width: '100%',
    borderRadius: 16,
    padding: 24,
    marginBottom: 32,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  resultTitle: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.lg,
    color: '#333',
    marginBottom: 16,
    textAlign: 'center',
  },
  resultItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  resultLabel: {
    fontFamily: FontFamilies.medium,
    fontSize: FontSizes.md,
    color: '#666',
  },
  resultValue: {
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    color: '#FF89A9',
  },
  imageContainer: {
    width: '100%',
    height: 150,
    borderRadius: 16,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  footer: {
    width: '100%',
    marginTop: 40,
  },
  button: {
    backgroundColor: '#FF89A9',
    height: 56,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#FF89A9',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  buttonText: {
    color: 'white',
    fontFamily: FontFamilies.semibold,
    fontSize: FontSizes.md,
    marginRight: 8,
  },
});